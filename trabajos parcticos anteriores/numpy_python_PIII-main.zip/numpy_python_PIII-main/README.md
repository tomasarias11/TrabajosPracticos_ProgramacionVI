Ing.Jesús Matías R.González

# Numpy y compresión de listas! [Python]
En este repositorio encontrarán los siguientes archivos:

__Ejemplos que el profesor mostrará en clase__\
ejemplos_clase/

__Ejercicios para que el alumno desarrolle lo visto en clase__\
ejercicios_practica/

__Ejercicios para que el alumno profundice sobre el tema durante la semana__\
ejercicios_profundizacion/

# Consultas
ingjesusmrgonzalez@gmail.com

