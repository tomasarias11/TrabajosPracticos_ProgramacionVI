

# SQL Introducción! [Python]
En este repositorio encontrarán los siguientes archivos:

__Ejemplos que el profesor mostrará en clase__\
ejemplos_clase.py

__Ejercicios para que el alumno desarrolle lo visto en clase__\
ejercicios_practica.py

__Ejercicios para que el alumno profundice sobre el tema durante la semana__\
ejercicios_profundizacion.md

# Consultas
ingjesusmrgonzalez@gmail.com

